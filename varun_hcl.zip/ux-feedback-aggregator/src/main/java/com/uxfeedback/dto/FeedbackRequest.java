package com.uxfeedback.dto;

import com.uxfeedback.model.FeedbackType;
import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class FeedbackRequest {
    
    @NotBlank(message = "User ID is required")
    private String userId;
    
    @NotBlank(message = "User name is required")
    private String userName;
    
    @Email(message = "Invalid email format")
    @NotBlank(message = "Email is required")
    private String userEmail;
    
    @NotNull(message = "Feedback type is required")
    private FeedbackType feedbackType;
    
    @NotBlank(message = "Title is required")
    @Size(min = 5, max = 200, message = "Title must be between 5 and 200 characters")
    private String title;
    
    @NotBlank(message = "Description is required")
    @Size(min = 10, max = 2000, message = "Description must be between 10 and 2000 characters")
    private String description;
    
    @Min(value = 1, message = "Rating must be between 1 and 5")
    @Max(value = 5, message = "Rating must be between 1 and 5")
    private Integer rating;
    
    private String pageUrl;
    private String browserInfo;
    private String status;
    private String priority;
}