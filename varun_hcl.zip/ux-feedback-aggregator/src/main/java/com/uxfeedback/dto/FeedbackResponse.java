package com.uxfeedback.dto;

import com.uxfeedback.model.FeedbackType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FeedbackResponse {
    
    private String id;
    private String userId;
    private String userName;
    private String userEmail;
    private FeedbackType feedbackType;
    private String title;
    private String description;
    private Integer rating;
    private String pageUrl;
    private String browserInfo;
    private List<String> attachmentPaths;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private String status;
    private String priority;
}