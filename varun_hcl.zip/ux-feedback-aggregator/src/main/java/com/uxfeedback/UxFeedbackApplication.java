package com.uxfeedback;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UxFeedbackApplication {
    public static void main(String[] args) {
        SpringApplication.run(UxFeedbackApplication.class, args);
    }
}