package com.uxfeedback.repository;

import com.uxfeedback.model.Feedback;
import com.uxfeedback.model.FeedbackType;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FeedbackRepository extends MongoRepository<Feedback, String> {
    
    List<Feedback> findByUserId(String userId);
    
    List<Feedback> findByFeedbackType(FeedbackType feedbackType);
    
    List<Feedback> findByStatus(String status);
    
    List<Feedback> findByPriority(String priority);
    
    List<Feedback> findByUserEmail(String email);
}