package com.uxfeedback.model;

public enum FeedbackType {
    BUG_REPORT,
    FEATURE_REQUEST,
    USABILITY_ISSUE,
    GENERAL_FEEDBACK,
    COMPLAINT,
    PRAISE
}