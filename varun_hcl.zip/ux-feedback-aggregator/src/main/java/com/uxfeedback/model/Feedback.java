package com.uxfeedback.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "feedbacks")
public class Feedback {
    
    @Id
    private String id;
    
    private String userId;
    private String userName;
    private String userEmail;
    
    private FeedbackType feedbackType;
    private String title;
    private String description;
    
    private Integer rating; // 1-5 scale
    private String pageUrl;
    private String browserInfo;
    
    private List<String> attachmentPaths; // File paths
    
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    
    private String status; // NEW, IN_PROGRESS, RESOLVED, CLOSED
    private String priority; // LOW, MEDIUM, HIGH, CRITICAL
}