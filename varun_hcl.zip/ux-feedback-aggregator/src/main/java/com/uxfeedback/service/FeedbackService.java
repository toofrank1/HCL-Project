package com.uxfeedback.service;

import com.uxfeedback.dto.FeedbackRequest;
import com.uxfeedback.dto.FeedbackResponse;
import com.uxfeedback.model.Feedback;
import com.uxfeedback.model.FeedbackType;
import com.uxfeedback.repository.FeedbackRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class FeedbackService {
    
    private final FeedbackRepository feedbackRepository = null;
    
    @Value("${file.upload-dir}")
    private String uploadDir;
    
    public FeedbackResponse createFeedback(FeedbackRequest request, List<MultipartFile> files) throws IOException {
        Feedback feedback = new Feedback();
        feedback.setUserId(request.getUserId());
        feedback.setUserName(request.getUserName());
        feedback.setUserEmail(request.getUserEmail());
        feedback.setFeedbackType(request.getFeedbackType());
        feedback.setTitle(request.getTitle());
        feedback.setDescription(request.getDescription());
        feedback.setRating(request.getRating());
        feedback.setPageUrl(request.getPageUrl());
        feedback.setBrowserInfo(request.getBrowserInfo());
        feedback.setStatus(request.getStatus() != null ? request.getStatus() : "NEW");
        feedback.setPriority(request.getPriority() != null ? request.getPriority() : "MEDIUM");
        feedback.setCreatedAt(LocalDateTime.now());
        feedback.setUpdatedAt(LocalDateTime.now());
        
        // Handle file uploads
        if (files != null && !files.isEmpty()) {
            List<String> filePaths = saveFiles(files);
            feedback.setAttachmentPaths(filePaths);
        }
        
        Feedback savedFeedback = feedbackRepository.save(feedback);
        return convertToResponse(savedFeedback);
    }
    
    public List<FeedbackResponse> getAllFeedbacks() {
        return feedbackRepository.findAll().stream()
                .map(this::convertToResponse)
                .collect(Collectors.toList());
    }
    
    public FeedbackResponse getFeedbackById(String id) {
        Feedback feedback = feedbackRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Feedback not found with id: " + id));
        return convertToResponse(feedback);
    }
    
    public List<FeedbackResponse> getFeedbacksByUserId(String userId) {
        return feedbackRepository.findByUserId(userId).stream()
                .map(this::convertToResponse)
                .collect(Collectors.toList());
    }
    
    public List<FeedbackResponse> getFeedbacksByType(FeedbackType type) {
        return feedbackRepository.findByFeedbackType(type).stream()
                .map(this::convertToResponse)
                .collect(Collectors.toList());
    }
    
    public List<FeedbackResponse> getFeedbacksByStatus(String status) {
        return feedbackRepository.findByStatus(status).stream()
                .map(this::convertToResponse)
                .collect(Collectors.toList());
    }
    
    public FeedbackResponse updateFeedback(String id, FeedbackRequest request) {
        Feedback feedback = feedbackRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Feedback not found with id: " + id));
        
        feedback.setTitle(request.getTitle());
        feedback.setDescription(request.getDescription());
        feedback.setRating(request.getRating());
        feedback.setStatus(request.getStatus());
        feedback.setPriority(request.getPriority());
        feedback.setUpdatedAt(LocalDateTime.now());
        
        Feedback updatedFeedback = feedbackRepository.save(feedback);
        return convertToResponse(updatedFeedback);
    }
    
    public void deleteFeedback(String id) {
        feedbackRepository.deleteById(id);
    }
    
    private List<String> saveFiles(List<MultipartFile> files) throws IOException {
        List<String> filePaths = new ArrayList<>();
        
        // Create upload directory if not exists
        File directory = new File(uploadDir);
        if (!directory.exists()) {
            directory.mkdirs();
        }
        
        for (MultipartFile file : files) {
            if (!file.isEmpty()) {
                String originalFilename = file.getOriginalFilename();
                String extension = originalFilename.substring(originalFilename.lastIndexOf("."));
                String newFilename = UUID.randomUUID().toString() + extension;
                
                Path filepath = Paths.get(uploadDir, newFilename);
                Files.write(filepath, file.getBytes());
                
                filePaths.add(filepath.toString());
            }
        }
        
        return filePaths;
    }
    
    private FeedbackResponse convertToResponse(Feedback feedback) {
        FeedbackResponse response = new FeedbackResponse();
        response.setId(feedback.getId());
        response.setUserId(feedback.getUserId());
        response.setUserName(feedback.getUserName());
        response.setUserEmail(feedback.getUserEmail());
        response.setFeedbackType(feedback.getFeedbackType());
        response.setTitle(feedback.getTitle());
        response.setDescription(feedback.getDescription());
        response.setRating(feedback.getRating());
        response.setPageUrl(feedback.getPageUrl());
        response.setBrowserInfo(feedback.getBrowserInfo());
        response.setAttachmentPaths(feedback.getAttachmentPaths());
        response.setCreatedAt(feedback.getCreatedAt());
        response.setUpdatedAt(feedback.getUpdatedAt());
        response.setStatus(feedback.getStatus());
        response.setPriority(feedback.getPriority());
        return response;
    }
}