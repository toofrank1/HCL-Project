package com.uxfeedback.controller;

import com.uxfeedback.dto.FeedbackRequest;
import com.uxfeedback.dto.FeedbackResponse;
import com.uxfeedback.model.FeedbackType;
import com.uxfeedback.service.FeedbackService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/api/feedbacks")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class FeedbackController {
    
    private final FeedbackService feedbackService = new FeedbackService();
    
    @PostMapping
    public ResponseEntity<FeedbackResponse> createFeedback(
            @Valid @ModelAttribute FeedbackRequest request,
            @RequestParam(value = "files", required = false) List<MultipartFile> files) {
        try {
            FeedbackResponse response = feedbackService.createFeedback(request, files);
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (IOException e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @GetMapping
    public ResponseEntity<List<FeedbackResponse>> getAllFeedbacks() {
        List<FeedbackResponse> feedbacks = feedbackService.getAllFeedbacks();
        return ResponseEntity.ok(feedbacks);
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<FeedbackResponse> getFeedbackById(@PathVariable String id) {
        try {
            FeedbackResponse feedback = feedbackService.getFeedbackById(id);
            return ResponseEntity.ok(feedback);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }
    }
    
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<FeedbackResponse>> getFeedbacksByUserId(@PathVariable String userId) {
        List<FeedbackResponse> feedbacks = feedbackService.getFeedbacksByUserId(userId);
        return ResponseEntity.ok(feedbacks);
    }
    
    @GetMapping("/type/{type}")
    public ResponseEntity<List<FeedbackResponse>> getFeedbacksByType(@PathVariable FeedbackType type) {
        List<FeedbackResponse> feedbacks = feedbackService.getFeedbacksByType(type);
        return ResponseEntity.ok(feedbacks);
    }
    
    @GetMapping("/status/{status}")
    public ResponseEntity<List<FeedbackResponse>> getFeedbacksByStatus(@PathVariable String status) {
        List<FeedbackResponse> feedbacks = feedbackService.getFeedbacksByStatus(status);
        return ResponseEntity.ok(feedbacks);
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<FeedbackResponse> updateFeedback(
            @PathVariable String id,
            @Valid @RequestBody FeedbackRequest request) {
        try {
            FeedbackResponse feedback = feedbackService.updateFeedback(id, request);
            return ResponseEntity.ok(feedback);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteFeedback(@PathVariable String id) {
        feedbackService.deleteFeedback(id);
        return ResponseEntity.noContent().build();
    }
}